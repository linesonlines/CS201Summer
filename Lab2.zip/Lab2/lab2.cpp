#include <iostream>
#include <iomanip>
using namespace std;
int main () {
bool go = true;
int initDay;
double grandTotal;
initDay = 1;
char ticketChoice;
const double priceChild = 10.95, priceAdult = 19.99, priceSenior = 18.99, priceVIP = 7.99;
int numChild, numAdult, numSenior, numVIP;
double totalChild, totalAdult, totalSenior, totalVIP;

cout << "Welcome to Fun Park Menu System !!" << endl;


for (initDay = 1; initDay < 4; initDay++) {
cout << "Starting day " << initDay << endl;
go = true;
totalChild = 0; 
totalAdult = 0; 
totalSenior = 0; 
totalVIP = 0;



while (go == true){
	
cout << "Enter (C)hild, (A)dult, (S)enior, (V)IP, or (Q)uit" << endl;

cin >> (ticketChoice);

if (toupper(ticketChoice) == 'C'){
	cout << "How many children? ";
	cin >> numChild;
	totalChild += numChild;
	
}
else if (toupper(ticketChoice) == 'A'){
	cout << "How many adults? ";
	cin >> numAdult;
	totalAdult += numAdult;
}

else if (toupper(ticketChoice) == 'S'){
	cout << "How many seniors? ";
	cin >> numSenior;
	totalSenior += numSenior;
}

else if (toupper(ticketChoice) == 'V'){
	cout << "How many VIP? ";
	cin >> numVIP;
	totalVIP += numVIP;
}

else if (toupper(ticketChoice) == 'Q'){
		double dailyTotal = 
totalChild * priceChild+
totalAdult * priceAdult+
totalSenior * priceSenior+
totalVIP * priceVIP;
	go = false;
	cout << "Day " << initDay << endl;
	cout << "Child " << totalChild << " @ " << priceChild << " = " << totalChild * priceChild<< endl;
	cout << "Adult " << totalAdult << " @ " << priceAdult << " = " << totalAdult * priceAdult << endl;
	cout << "Senior " << totalSenior << " @ " << priceSenior << " = " << totalSenior * priceSenior << endl;
	cout << "VIP " << totalVIP << " @ " << priceVIP << " = " << totalVIP * priceVIP << endl << endl;
	cout << "Total = " << dailyTotal << endl;
	
	grandTotal += dailyTotal;
	
}
}
}
cout << "Grand Total: " <<grandTotal << endl;
}