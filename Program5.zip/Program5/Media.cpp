#include <iostream>
#include <string>
#include "Headers.h"
using namespace std;

	Media::Media(string id_p, string account_p, int time_p){
		id = id_p;
		account = account_p;
		time = time_p;
	}
	void Media::setId(string id_p){
		id = id_p;
	}
	void Media::setAcc(string account_p){
		account = account_p;
	}
	void Media::setTime(int time_p){
		time = time_p;
	}
	string Media::getId(){
		return id;
	}
	string Media::getAcc(){
		return account;
	}
	int Media::getTime(){
		return time;
	}
	string Media::readData(istream& fin){
		string time_str;
		string acct_s;
		string build_acct = "";
		fin >> id;
		fin >> acct_s;
		bool first = true;
		while (!(acct_s.find_first_not_of("0123456789") == string::npos)){
			if (first) {
				build_acct = build_acct + acct_s;
				first = false;
			} else {
				build_acct = build_acct + " " + acct_s;
			}
			fin >> acct_s;
		}
		time_str = acct_s;
		account = build_acct;
		time = stoi(time_str);
		return "";
    }
    void Media::writeData(ostream& fout){
		fout << id << endl;
		fout << account << endl;
		fout << time << endl;
    }
