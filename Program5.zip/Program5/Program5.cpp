#include <iostream>
#include <fstream>
#include "Headers.h"
using namespace std;

int main() {
  ifstream fin("Program5Data.txt");
  ofstream fout("video.txt");
  ofstream fout2("audio.txt");

  string m_type;

  Media *m[200];
  int index = 0;

  fin >> m_type;
  while (!fin.eof()){
    if (m_type == "A") {
      Audio* pa = new Audio();
      m[index] = pa;
      m_type = m[index]->readData(fin);
    } else if (m_type == "V")  {
      Video* pv = new Video();
      m[index] = pv;
      m_type = m[index]->readData(fin);
    } else {
      break;
    }
    index++;
  }
  fin.close();

  for (int i = 0; i < index; i++) {
    if (m[i]->getType() == "A") {
      m[i]->writeData(fout2);
    } else if (m[i]->getType() == "V") {
      m[i]->writeData(fout);
    }
  }
  fout.close();
  fout2.close();
  return 0;
}