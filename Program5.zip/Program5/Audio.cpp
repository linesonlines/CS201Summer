#include "Headers.h"
#include <iostream>
using namespace std;

	Audio::Audio():Media("", "", 1){
		format = "";
        quality = "";
	}
	string Audio::readData(istream& fin)
	{		
		Media::readData(fin);
		fin >> format;
		string build_qual = "";
		string q_s;
		fin >> q_s;
		bool first = true;
		int index = 1;
		while (q_s != "V" && q_s != "A" && !fin.eof()){
			if (first) {
				build_qual = build_qual + q_s;
				first = false;
			} else {
				build_qual = build_qual + " " + q_s;
			}
			fin >> q_s;
		}
		quality = build_qual;
		if (q_s == "V" || q_s == "A"){
			return q_s;
		} else {
			return "Done";
		}

    }
    void Audio::writeData(ostream& fout)
	{
        Media::writeData(fout);
		fout << format << endl;
		fout << quality << endl;
		fout << "******************" << endl;
    }
	string Audio::getType(){
		return "Audio";
	}
