#include <iostream>
using namespace std;

class Media {       
protected:
	string id;
	string account;
	int time;
	
public:
	Media(string id_p, string account_p, int time_p);
	void setId(string id_p);
	void setAcc(string account_p);
	void setTime(int time_p);
	string getId();
	string getAcc();
	int getTime();
	virtual string readData(istream& fin);
	virtual void writeData(ostream& fout);
	virtual string getType() = 0;
};

class Video : public Media 
{
private:
	string format;
	string quality;
    string reso;

public:
    Video();
	string readData(istream& fin);
	void writeData(ostream& fout);
	string getType();
};

class Audio : public Media 
{
private:
	string format;
	string quality;

public:
    Audio();
	string readData(istream& fin);
	void writeData(ostream& fout);
	string getType();
};