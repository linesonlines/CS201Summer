#include <iostream>
#include <stdexcept>
#include <vector>
using namespace std;

double getMiles(){
	double numberMiles = 0;
  cout << "Enter the number of miles: " << endl;
  cin >> numberMiles;
  if (cin.fail()) {
    // Clear error state
    cin.clear();
    // Ignore characters in stream until newline
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
		throw runtime_error("Invalid input received, you must enter a decimal number.");
  } else if (numberMiles <= 0) {
		throw runtime_error("Invalid input received, miles must be more than 0.");
  } else {
  	return numberMiles;
  }
	return numberMiles;
}

double getGallons() {
	double numberGalls = 0;
  cout << "Enter the number of gallons: " << endl;
  cin >> numberGalls;
  if (cin.fail()) {
    // Clear error state
    cin.clear();
    // Ignore characters in stream until newline
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
		throw runtime_error("Invalid input received, you must enter a decimal number.");
  } else if (numberGalls <= 0) {
		throw runtime_error("Invalid input received, gallons must be more than 0.");
  } else {
  	return numberGalls;
  }
	return numberGalls;
}

bool getAnotherTank() {
	string answer = "";
  cout << "Would you like to enter another tank? Enter Y or N." << endl;
  cin >> answer;
  if (answer != "Y" && answer !="y"
	&& answer != "N" && answer != "n") {
		throw runtime_error("Invalid input received.");
  } else {
  	return (answer == "Y" || answer == "y");
  }
	return false;
}

double getMPG(vector<double> miles, vector<double> gallons) {
	if (miles.size() == 0 || gallons.size() == 0) {
		throw runtime_error("Error: No values were entered.");
	} else {
		double milesSum;
		double gallsSum;
		for (int i = 0; i < miles.size(); i++) {
			milesSum += miles.at(i);
		}
		for (int i = 0; i < gallons.size(); i++) {
			gallsSum += gallons.at(i);
		}
		return milesSum/gallsSum;
	}
}

int main () {
	bool validating;
	double miles, gallons;
	bool goAgain = true;
	vector<double> allMiles;
	vector<double> allGalls;
	while (goAgain) {
		validating = true;
		while (validating) {
			try {
				miles = getMiles();
				validating = false;
			}
			catch (runtime_error &excpt) {
				cout << excpt.what() << endl;
			}
		}
		validating = true;
		while (validating) {
			try {
				gallons = getGallons();
				validating = false;
			}
			catch (runtime_error &excpt) {
				cout << excpt.what() << endl;
			}
		}
		allMiles.push_back(miles);
		allGalls.push_back(gallons);
		validating = true;
		while (validating){
			try {
				goAgain = getAnotherTank();
				validating = false;
			}
			catch (runtime_error &excpt) {
				cout << excpt.what() << endl;
			}
		}
	}
	double finalMPG;
	try {
		finalMPG = getMPG(allMiles, allGalls);
		cout << "Final MPG: ";
		cout.precision(2);
		cout << fixed << finalMPG << endl;
	} catch (runtime_error &excpt) {
		cout << excpt.what() << endl;
	}
	return 0;
}