#include <iostream>
#include <string>
#include <vector>
using namespace std;

int getRows(string f_or_s){
	int rows;
	cout << "Enter the number of rows for the " << f_or_s << " matrix: " << endl;
	cin >> rows;
	return rows;
}

int getCols(string f_or_s){
	int cols;
	cout << "Enter the number of columns for the " << f_or_s << " matrix: " << endl;
	cin >> cols;
	return cols;
}

vector<int> getValues(int rows, int cols){
	cout << "Enter all the values in the matrix, separated by a space." << endl;
	int i = 0;
	int val;
	vector<int> vals;
	while (i < (rows * cols)){
		cin >> val;
		vals.push_back(val);
		i++;
	}
	return vals;
}

void printMatrix(int matrix[20][20], int r, int c){
	for (int i=0; i < r; i++){
		for (int j=0; j < c; j++){
			cout << matrix[i][j] << " ";
		}
		cout << endl;
	}
}

void add(int matrix_1[20][20], int matrix_2[20][20], int r, int c){
	int newMatrix[20][20];
	cout << "The first grid + the second grid: " << endl;
	for (int i=0; i < r; i++){
		for (int j=0; j < c; j++){
			newMatrix[i][j] = matrix_1[i][j] + matrix_2[i][j];
		}
	}
	printMatrix(newMatrix,r,c);
}

void multiply(int matrix_1[20][20], int matrix_2[20][20], int r1, int c2, int r2){
	int r = r1;
	int c = c2;
	int newMatrix[20][20];
	cout << "The first grid * the second grid: " << endl;
  for(int i=0; i<r1; i++){
      for(int j=0; j<c2; j++){
          int sum =0;
          for(int k=0; k<r2; k++){
              sum += (matrix_1[i][k] * matrix_2[k][j]);
          }
          newMatrix[i][j] = sum;
      }
  }
	printMatrix(newMatrix,r,c);
}

int main () {
	int matrix_1[20][20];
	int r1 = getRows("first");
	int c1 = getCols("first");
	vector<int> v = getValues(r1,c1);
	int r = 0;
	int c = 0;
	for (int i= 0; i < v.size(); i++){
		matrix_1[r][c] = v.at(i);
		if (c == (c1-1)){
			c = 0;
			r++;
		} else {
			c++;
		}
	}
	cout << "This is the first matrix you entered:" << endl;
	printMatrix(matrix_1, r1, c1);
	
	int matrix_2[20][20];
	int r2 = getRows("second");
	int c2 = getCols("second");
	v = getValues(r2,c2);
	r = 0;
	c = 0;
	for (int i= 0; i < v.size(); i++){
		matrix_2[r][c] = v.at(i);
		if (c == (c2-1)){
			c = 0;
			r++;
		} else {
			c++;
		}
	}
	cout << "This is the second matrix you entered:" << endl;
	printMatrix(matrix_2, r2, c2);
	
	if (r1 == r2 && c1 == c2) {
		add(matrix_1, matrix_2, r1, c1);
	} else {
		cout << "Cannot add these matrices." << endl;
	}
	
	if (c1 == r2) {
		multiply(matrix_1, matrix_2, r1, c2, r2);
	} else {
		cout << "Cannot multiply these matrices." << endl;
	}
	
	return 0;
}