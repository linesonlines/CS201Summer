#include <string>
#include "LibraryBook.h"
using namespace std;

  LibraryBook::LibraryBook() {
	  title = "";
	  author = "";
	  isbn = "";
	  checkedOut = false;
	}

	LibraryBook::LibraryBook(string titleP, string authorP, string isbnP) {
	 title = titleP;
	 author = authorP;
	 isbn = isbnP;
	 checkedOut = false;
	}
	 
	 void LibraryBook::setTitle(string titleP) {
		 title = titleP;
	 }
	 
	 void LibraryBook::setAuthor(string authorP) {
		 author = authorP;
	 }
	 
	 void LibraryBook::setISBN(string isbnP) {
		 isbn = isbnP;
	 }
	 
	 void LibraryBook::checkOut() {
		 checkedOut = true;
	 }
	 
	 void LibraryBook::checkIn() {
		 checkedOut = false;
	 }
	 
	 string LibraryBook::getTitle() {
		 return title;
	 }
	 
	 string LibraryBook::getAuthor() {
		 return author;
	 }
	 
	 string LibraryBook::getISBN() {
		 return isbn;
	 }
	 
	 bool LibraryBook::isCheckedOut(){
		 return checkedOut;
	 }