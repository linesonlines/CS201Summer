#include <string>
using namespace std;

class LibraryBook {       
private:             
  string title;
	string author;
	string isbn;
	bool checkedOut;
	
public:
	LibraryBook();
	LibraryBook(string titleP, string authorP, string isbnP);
	void setTitle(string titleP);
	void setAuthor(string authorP);
	void setISBN(string isbnP);
	void checkOut();
	void checkIn();
	string getTitle();
	string getAuthor();
	string getISBN();
	bool isCheckedOut();
};