#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include "LibraryBook.h"
using namespace std;

int main() {
	string title;
	string author;
	string isbn;
	map<string, LibraryBook> libraryBooks;
	ifstream fin("books.txt");
	while (!fin.eof()){
		getline(fin, title);
		getline(fin, author);
		getline(fin, isbn);
		libraryBooks.insert(make_pair(isbn, LibraryBook(title, author, isbn)));
	}
	fin.close();
	string nextISBN;
	ifstream fin2("isbns.txt");
	LibraryBook book;
	while (!fin2.eof()){
		getline(fin2, nextISBN);
		auto i = libraryBooks.find(nextISBN);
		book = i->second;
		if (book.isCheckedOut()){
			book.checkIn();
		  //cout << "Checking in..." << book.getTitle() << endl;
			i->second = book;
		} else {
			book.checkOut();
			//cout << "Checking out..." << book.getTitle() << endl;
			i->second = book;
		}
	}
	fin2.close();
	ofstream fout("checkedout.csv");
	const string qt = "\"";
	const string endqt = "\",";
	fout << qt << "Title" << endqt;
	fout << qt << "Author" << endqt;
	fout << qt << "ISBN" << endqt << endl;
	for (auto const& b : libraryBooks)
	{
		book = b.second;
		if (book.isCheckedOut()){
		  fout << qt << book.getTitle() << endqt;
		  fout << qt << book.getAuthor() << endqt;
		  fout << qt << book.getISBN() << endqt << endl;
		}
	}
	fout.close();
	
  return 0;
}