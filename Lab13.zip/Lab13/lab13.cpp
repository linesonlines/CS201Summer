#include <iostream>
#include <fstream>
#include <string>
using namespace std;

ofstream fout("output.txt");
const int SIZE = 100;

template <typename T> T myMin(T ar[SIZE], int size){
    int index = 0;
    T smallest = ar[0];
    while (index < size) {
        if (ar[index] < smallest) {
            smallest = ar[index];
        }
        index++;
    }
    fout << "Minimum: " << smallest << endl;
    return smallest;
}

template <typename T> T myMax(T ar[SIZE], int size){
    int index = 0;
    T largest = ar[0];
    while (index < size) {
        if (ar[index] > largest) {
            largest = ar[index];
        }
        index++;
    }
    fout << "Maximum: " << largest << endl;
    return largest;
}

template <typename T> void mySwap(T ar[SIZE], int size, int pos1, int pos2) {
    fout << "Swapped items at positions " << pos1 << " and " << pos2 << endl;
    fout << "Before: [10] " << ar[pos1];
    fout << " [20] " << ar[pos2] << endl;
    T temp = ar[pos1];
    ar[pos1] = ar[pos2];
    ar[pos2] = temp;
    fout << "After: [10] " << ar[pos1];
    fout << " [20] " << ar[pos2] << endl;
}

template <typename T> int mySearch(T ar[SIZE], int size, T target){
    fout << target << " is at position ";
    int index = 0;
    while (index < size) {
        if (ar[index] == target) {
            fout << index << endl;
            return index;
        }
        index++;
    }
    fout << -1 << endl;
    return -1;
}

int main () {
    int intArray [SIZE];
    double dubArray [SIZE];
    string sArray [SIZE];
    int index = 0;
    ifstream fin("integers.txt");
    int i;
    while (!fin.eof())
	{
        fin >> i;
        intArray[index] = i;
        index++;
    }
    fin.close();
    fout << "Integers:" << endl;
    mySwap(intArray, SIZE, 10, 20);
    myMin(intArray, SIZE);
    myMax(intArray, SIZE);
    fout << "The number ";
    mySearch(intArray, SIZE, 1);
    fout << "The number ";
    mySearch(intArray, SIZE, 5);

    index = 0;
    ifstream fin2("doubles.txt");
    double d;
    while (!fin2.eof())
	{
        fin2 >> d;
        dubArray[index] = d;
        index++;
    }
    fin2.close();
    fout << endl << "Doubles:" << endl;
    mySwap(dubArray, SIZE, 10, 20);
    myMin(dubArray, SIZE);
    myMax(dubArray, SIZE);
    fout << "The number ";
    mySearch(dubArray, SIZE, 4.62557);
    fout << "The number ";
    mySearch(dubArray, SIZE, 1.23456);

    index = 0;
    ifstream fin3("strings.txt");
    string s;
    while (!fin3.eof())
	{
        fin3 >> s;
        sArray[index] = s;
        index++;
    }
    fin3.close();
    fout << endl << "Strings:" << endl;
    mySwap(sArray, SIZE, 10, 20);
    myMin(sArray, SIZE);
    myMax(sArray, SIZE);
    fout << "The word ";
    mySearch(sArray, SIZE, (string)"Shoes");
    fout << "The word ";
    mySearch(sArray, SIZE, (string)"Pumpkin");
    fout.close();
    return 0;
}

