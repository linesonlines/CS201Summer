#include <iostream>
#include <fstream>
#include <string>
using namespace std;

const int arraySize = 10;

void printCustomerData(int id[arraySize],
	string firstName[arraySize],
	string lastName[arraySize],
	float savings[arraySize],
	float checking[arraySize]){
  cout.width(12);
	cout << left << "Last";
	cout.width(12);
	cout << left << "First";
	cout.width(8);
	cout << left << "ID";
  cout.width(15);
	cout << left << "Savings";
	cout.width(15);
	cout << left << "Checking" << endl;
	for (int i=0; i < arraySize; i++) {
  		cout.width(12);
			cout << left << lastName[i];
			cout.width(12);
			cout << left << firstName[i];
			cout.width(8);
			cout << left << id[i];
  		cout.width(15);
			cout.precision(2);
			cout << left << fixed << savings[i];
			cout.width(15);
			cout.precision(2);
			cout << left << fixed << checking[i] << endl;
		}
}

void printNames (string firsts[arraySize], string lasts[arraySize]){
	for(int i=0;i<arraySize;i++)
  {
     for(int j=i+1;j<arraySize;j++)
		 {
			 if(firsts[i] > firsts[j] || (firsts[i] == firsts[j] &&
        	lasts[i] > lasts[j]))
       {
          string swap = firsts[i];
          firsts[i] = firsts[j];
          firsts[j] = swap;
					swap = lasts[i];
					lasts[i] = lasts[j];
					lasts[j] = swap;
        }
		 }
  }
  cout<<"Sorted by First Name:"<<endl;
	int total = 0;
  cout.width(12);
	cout << left << "First";
	cout.width(12);
	cout << left << "Last" << endl;
  for(int i=0;i<arraySize;i++)
  {
		if (firsts[i] != ""){
			total++;
  		cout.width(12);
			cout << left << firsts[i];
			cout.width(12);
			cout << left << lasts[i] << endl;
			
		}
  }
	cout << endl;
	cout << "Total number of customers: " << total << endl;
}

void printBankTotals(int id[arraySize],
	string firstName[arraySize],
	string lastName[arraySize],
	float savings[arraySize],
	float checking[arraySize]){
	float total;
  cout.width(12);
	cout << left << "Last";
	cout.width(12);
	cout << left << "First";
	cout.width(8);
	cout << left << "ID";
  cout.width(15);
	cout.precision(2);
	cout << left << "Savings";
	cout.width(15);
	cout.precision(2);
	cout << left << "Checking";
	cout.width(15);
	cout.precision(2);
	cout << left << "Total" << endl;
	for (int i=0; i < arraySize; i++) {
			total = savings[i] + checking[i];
  		cout.width(12);
			cout << left << lastName[i];
			cout.width(12);
			cout << left << firstName[i];
			cout.width(8);
			cout << left << id[i];
  		cout.width(15);
			cout.precision(2);
			cout << left << fixed << savings[i];
			cout.width(15);
			cout.precision(2);
			cout << left << fixed << checking[i];
			cout.width(15);
			cout.precision(2);
			cout << left << fixed << total << endl;
		}
}



int main () {
	const int columnNum = 5;
	int id[arraySize];
	string firstName[arraySize];
	string lastName[arraySize];
	float savings[arraySize];
	float checking[arraySize];
	
	int lineNumber = 0;
	
	ifstream fin("input.txt");
	string idString,firstNameString,lastNameString,savingsString,checkingString;
	while (!fin.eof())
	{
		fin >> idString >> firstNameString >> lastNameString >> savingsString >> checkingString;
		id[lineNumber] = stoi(idString);
		firstName[lineNumber] = firstNameString;
		lastName[lineNumber] = lastNameString;
		savings[lineNumber] = stof(savingsString);
		checking[lineNumber] = stof(checkingString);
		lineNumber++;
		//cout << idString << firstNameString << lastNameString << savingsString << checkingString << endl;
	}
	fin.fail();
	
	string selection;
	int sel;
	bool running = true;
	
	while (running) 
	{
		cout << endl;
		cout << "1. Print customer data" << endl;
		cout << "2. Print customer names" << endl;
		cout << "3. Print customer data with totals" << endl;
		cout << "Enter your choice or q/Q to quit: ";
		cin >> selection;
		
		if (selection == "q" || selection == "Q") 
		{
			cout << "Thanks for using my program. Goodbye!" << endl;
			running = false;
		} else if (selection == "1" || selection == "2" || selection == "3" )
		{
			sel = stoi(selection);
			switch(sel) {
			  case 1:
			  printCustomerData(id,firstName,lastName,savings,checking);
			    break;
			  case 2:
			  printNames(firstName, lastName);
			    break;
				case 3:
				printBankTotals(id,firstName,lastName,savings,checking);
				  break;
			}
		} else {
			cout << "Invalid selection. Please enter 1, 2, 3, or q/Q to quit." << endl;
		}
	}
	return 0;
}
