#include <iostream>
#include <iomanip>
using namespace std;

void withdrawBank(float account, float amount){
	if (amount > account){
		cout << "Balance too low to withdraw. " << endl;	
	}
	else if (amount < 0){
		cout << "No negative values accepted. Please try again. u dumfuq. " << endl;
	}
	else {
		account = account - amount;
	}
	cout << account << endl;
}

void depositBank(float& account, float amount){
	account = account + amount;
	cout << account << endl;
}
	
int main () {
	char userInput; 
	float wAmount;
	float dAmount;
	float account = 500;
	float amount;
	cout << account << endl;
	
	cout << "(W)ithdraw or (D)eposit or (L)oan or (Q)uit? " << endl;
	cin >> userInput;
	if (toupper(userInput) == 'W'){
		cout << "Insert Withdrawal Amount: " << endl;
		cin >> wAmount;
		withdrawBank(account,wAmount);
		
	} else if (toupper(userInput) == 'D'){
		cout << "Insert Deposit Amount: " << endl;
		cin >> dAmount;
		depositBank(account,dAmount);
	}
			
return 0;
}