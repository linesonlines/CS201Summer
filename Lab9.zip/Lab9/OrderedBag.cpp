#include <vector>
#include <iostream>
#include "Bag.h"
#include "OrderedBag.h"
using namespace std;

int OrderedBag::remove_item() {
	if (bag.size() == 0){
		throw runtime_error("Bag is empty, cannot remove item");
	} else {
		int smallest = bag.at(0);
		int smallIndex = 0;
		for (int i = 1; i < bag.size(); i++) {
			if (bag.at(i) < smallest) {
				smallest = bag.at(i);
				smallIndex = i;
			}
		}
		int temp = bag.at(bag.size()-1);
		bag.at(bag.size()-1) = smallest;
		bag.at(smallIndex) = temp;
		bag.pop_back();
		return smallest;
	}
}
	
