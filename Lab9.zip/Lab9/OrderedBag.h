#include <vector>
using namespace std;

class OrderedBag : public Bag {       	
public:
	int remove_item();
};