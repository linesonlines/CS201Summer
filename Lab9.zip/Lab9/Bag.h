#include <vector>
using namespace std;

class Bag {       
protected:             
  vector<int> bag;
	
public:
	Bag();
	bool add_item(int item);
	bool delete_item(int item);
	void delete_all(int item);
	void clear();
	int size();
	virtual int remove_item();
};