#include <iostream>
#include <fstream>
#include "Bag.h"
#include "OrderedBag.h"
using namespace std;

void printCommands(ifstream& fin, ofstream& fout, Bag& b){
	string letter;
	int number;
	bool success;
	bool end = false;
	while (!end)
	{
		fin >> letter;
		if (letter == "A")
		{
			fin >> number;
			success = b.add_item(number);
			if (success)
			{
			  fout << "Adding " << number << endl;
			}
		}
		else if (letter == "D") 
		{
			fin >> number; 
			success = b.delete_item(number);
			if (success)
			{
			  fout << "Deleting " << number << endl;
			}
			else 
			{
				fout << "Could not find " << number << " to delete." << endl;
			}
		} 
		else if (letter == "Z") 
		{
			fin >> number;
			b.delete_all(number);
			fout << "Deleting all instances of " << number << endl;
		} 
		else if (letter == "R")
		{
			try {
				number = b.remove_item();
				fout << "Removing " << number << endl;
			} catch (runtime_error &excpt) {
				cout << excpt.what() << endl;
			}
		}
		if (fin.eof()){
			end = true;
			fout << "There are " << b.size() << " items left in the bag.";
		}
	}
}

int main() {
	ifstream fin("test.txt");
	ofstream fout("output.txt");
	Bag b;
	printCommands(fin, fout, b);
	ifstream fin2("test.txt");
	ofstream fout2("output_ordered.txt");
	OrderedBag ob;
	printCommands(fin2, fout2, ob);
	fin.close();
	fout.close();
	fin2.close();
	fout2.close();
  return 0;
}