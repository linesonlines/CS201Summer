#include <vector>
#include <iostream>
#include "Bag.h"
using namespace std;

  Bag::Bag() {
		vector<int> newBag;
		bag = newBag;
	}
	 
	bool Bag::add_item(int item) {
		try
		{
		   bag.push_back(item);
			 return true;
		} catch(std::bad_alloc& excpt)
		{
		   cout << excpt.what() << endl;
		}
		return false;
  }
	
	int Bag::remove_item() {
		if (bag.size() == 0){
			throw runtime_error("Bag is empty, cannot remove item");
		} else {
			int item = bag.at(bag.size() - 1);
			bag.pop_back();
			return item;
		}
  }
	
	bool Bag::delete_item(int item) {
		vector<int> newBag;
		bool found = false;
		while (bag.size() > 0 && found == false){
			int transfer = bag.at(bag.size() - 1);
			bag.pop_back();
			if (transfer != item) {
				newBag.push_back(transfer);
			} else {
				found = true;
			}
		}
		bag.insert(bag.end(), newBag.begin(), newBag.end());
		return found;
	}
	
	void Bag::delete_all(int item) {
		vector<int> newBag;
		while (bag.size() > 0){
			int transfer = bag.at(bag.size() - 1);
			bag.pop_back();
			if (transfer != item) {
				newBag.push_back(transfer);
			}
		}
		bag.insert(bag.end(), newBag.begin(), newBag.end());
	}
	
	void Bag::clear(){
		bag.clear();
	}
	
	int Bag::size(){
		return bag.size();
	}
