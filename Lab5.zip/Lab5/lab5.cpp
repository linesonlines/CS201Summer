#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cmath>
using namespace std;

struct Point { // This structure is named "myDataType"
	double x;
	double y;
	double z;
};

double calcDist(Point p1, Point p2){
	return sqrt(pow(p1.x-p2.x,2) + pow(p1.y-p2.y,2) + pow(p1.z-p2.z,2));
}

vector<double> getDistances(vector<Point> points){
	double distance; 
	vector<double> distances;
	for (int i = 0; i < points.size(); i+=2)
	{
		Point p1 = points.at(i);
		Point p2 = points.at(i+1);
		distance = calcDist(p1, p2);
		distances.push_back(distance);
	}
	return distances;
}

void sortDistances(vector<double>& distances) 
{
	double temp;
  for (int i = 0; i < distances.size(); i++) {     
      for (int j = i+1; j < distances.size(); j++) {     
         if(distances.at(i) > distances.at(j)) {    
             temp = distances.at(i);    
             distances.at(i) = distances.at(j);    
             distances.at(j) = temp;    
         }     
     }     
  }  
}


int main () {
	vector<Point> points;
	vector<double> distances;
	ifstream fin("input.txt");
	double x,y,z,x2,y2,z2;
	while (!fin.eof())
	{
		fin >> x >> y >> z >> x2 >> y2 >> z2;
		Point point1;
		point1.x = x;
		point1.y = y;
		point1.z = z;
		Point point2;
		point2.x = x2;
		point2.y = y2;
		point2.z = z2;
		points.push_back(point1);
		points.push_back(point2);
	}
	fin.fail();
	distances = getDistances(points);
	ofstream fout("output.txt");
	for (int i; i < distances.size(); i++)
	{
		fout << distances[i] << endl;
	}
	fout.close();
	ofstream fout2("output_sorted.txt");
	sortDistances(distances);
	for (int i; i < distances.size(); i++)
	{
		fout2 << distances[i] << endl;
	}
	fout2.close();
	return 0;
}
