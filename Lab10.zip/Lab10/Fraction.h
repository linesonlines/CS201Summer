#pragma once
// Captain Daryani
// Lab 10
#include <iostream>
using namespace std;
class Fraction
{
// Add the variables and functions you need to. getGCD and reduce are 
// provided for you.
private:
    int numerator;
    int denominator;
    int getGCD(int num1, int num2);
    void reduce();
public:
    Fraction();
    Fraction(int n, int d);
    friend ostream& operator<< (ostream& output, const Fraction& fract);
    friend istream& operator>> (istream& input, Fraction& fract);
    const Fraction operator+ (const Fraction& rhs);
    const Fraction operator- (const Fraction& rhs);
    const Fraction operator* (const Fraction& rhs);
    const Fraction operator/ (const Fraction& rhs);
    bool operator== (const Fraction& rhs);
};