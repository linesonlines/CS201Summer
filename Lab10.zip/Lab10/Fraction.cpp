// Captain Daryani
// Lab 10
#include "Fraction.h"
#include <iostream>
#include <string>
using namespace std;

Fraction::Fraction() {
   numerator = 0;
   denominator = 0;
}

Fraction::Fraction(int n, int d) {
   numerator = n;
   denominator = d;
}

// Find the greatest common denominator (GCD)
// For reducing
int Fraction::getGCD(int num1, int num2)
{
   int remainder = num2 % num1;
   if (remainder != 0){
      return getGCD(remainder, num1);
   }
   else {
      return num1;
   }
}

// Reduce/simplify a fraction
void Fraction::reduce()
{
// Alter this function later to adjust for negative values
   int gcd = getGCD(numerator, denominator);
   numerator /= gcd;
   denominator /= gcd;

   if (numerator < 0 && denominator < 0) {
      numerator *= -1;
      denominator *= -1;
   } else if (numerator > 0 && denominator < 0) {
      numerator *= -1;
      denominator *= -1;
   }
}

ostream& operator<< (ostream& output, const Fraction& fract){
   output << fract.numerator;
   output << "/";
   output << fract.denominator;
   return output;
}

istream& operator>> (istream& input, Fraction& fract){
   input >> fract.numerator;
   char slash;
   input >> slash;
   input >> fract.denominator;
   return input;
}

const Fraction Fraction::operator+ (const Fraction& rhs) {
   int n1 = numerator * rhs.denominator;
   int n2 = rhs.numerator * denominator;
   int finalN = n1 + n2;
   int finalD = denominator * rhs.denominator;
   Fraction newOne = Fraction(finalN, finalD);
   newOne.reduce();
   return newOne;
}

const Fraction Fraction::operator- (const Fraction& rhs) {
   int n1 = numerator * rhs.denominator;
   int n2 = rhs.numerator * denominator;
   int finalN = n1 - n2;
   int finalD = denominator * rhs.denominator;
   Fraction newOne = Fraction(finalN, finalD);
   newOne.reduce();
   return newOne;
}

const Fraction Fraction::operator* (const Fraction& rhs) {
   Fraction newOne = Fraction(numerator * rhs.numerator, 
   denominator * rhs.denominator);
   newOne.reduce();
   return newOne;
}

const Fraction Fraction::operator/ (const Fraction& rhs) {
   Fraction newOne = Fraction(numerator * rhs.denominator, 
   denominator * rhs.numerator);
   newOne.reduce();
   return newOne;
}

bool Fraction::operator== (const Fraction& rhs) {
   Fraction leftOne = Fraction(numerator, denominator);
   leftOne.reduce();
   Fraction rightOne = Fraction(rhs.numerator, rhs.denominator);
   rightOne.reduce();
   if (leftOne.numerator == rightOne.numerator &&
   leftOne.denominator == rightOne.denominator){
      return true;
   } else {
      return false;
   }
}